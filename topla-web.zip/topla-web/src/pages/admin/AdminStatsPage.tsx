import { useMemo } from 'react'
import {
  Bar,
  BarChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip as RechartsTooltip,
  XAxis,
  YAxis,
} from 'recharts'
import { format } from 'date-fns'
import { az } from 'date-fns/locale'
import { MapPin, Ticket, UserCheck } from 'lucide-react'
import {
  Card,
  CardBody,
  CardHeader,
  ChartCard,
  ChartTooltip,
  ErrorState,
  Skeleton,
  StatCard,
  axisProps,
  chartTheme,
} from '@/components/ui'
import { BookingStatusBadge } from '@/components/common/StatusBadge'
import { AdminPageHeader } from '@/features/admin/AdminPageHeader'
import { MissingEndpointNotice } from '@/features/admin/MissingEndpointNotice'
import { usePlatformStats } from '@/hooks/queries/useAdminQueries'
import { useAdminBookings } from '@/hooks/queries/useBookingQueries'
import { usePageMeta } from '@/hooks/usePageMeta'
import { errorMessage } from '@/api'
import { resolveBookingState } from '@/utils/booking'
import { formatNumber, toDate } from '@/utils/format'
import type { BookingDetail, BookingUiStatus } from '@/types'

const SAMPLE_SIZE = 100
const STATES: BookingUiStatus[] = ['pending', 'confirmed', 'completed', 'cancelled']

/** Zaman seriyası endpoint-i olmadığı üçün son N bron client tərəfdə aylara yığılır. */
function bookingsByMonth(bookings: BookingDetail[]): { label: string; value: number }[] {
  const buckets = new Map<string, { label: string; value: number }>()

  for (const booking of bookings) {
    const date = toDate(booking.startDateTime)
    if (!date) continue
    const key = format(date, 'yyyy-MM')
    const bucket = buckets.get(key)
    if (bucket) bucket.value += 1
    else buckets.set(key, { label: format(date, 'LLL yy', { locale: az }), value: 1 })
  }

  return [...buckets.entries()]
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([, bucket]) => bucket)
}

export default function AdminStatsPage() {
  usePageMeta({ title: 'Statistika — Admin' })

  const stats = usePlatformStats()
  const bookings = useAdminBookings(1, SAMPLE_SIZE)

  const items = useMemo(() => bookings.data?.items ?? [], [bookings.data])
  const points = useMemo(() => bookingsByMonth(items), [items])
  const byState = useMemo(() => {
    const counts = new Map<BookingUiStatus, number>()
    for (const booking of items) {
      const state = resolveBookingState({
        status: booking.status,
        endDateTime: booking.endDateTime,
      })
      counts.set(state, (counts.get(state) ?? 0) + 1)
    }
    return counts
  }, [items])

  const statValue = (value: number | undefined) =>
    stats.isError || value == null ? '—' : formatNumber(value)

  return (
    <div className="space-y-5">
      <AdminPageHeader
        title="Statistika"
        description="Yalnız real endpoint-lərdən yığılan göstəricilər — proqnoz və ya nümunə data yoxdur."
      />

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        <StatCard
          label="Ümumi rezervasiyalar"
          value={statValue(stats.data?.totalBookings)}
          hint="Platforma üzrə bütün bronlar"
          icon={<Ticket />}
          loading={stats.isLoading}
        />
        <StatCard
          label="Dərc olunmuş stadionlar"
          value={statValue(stats.data?.publishedStadiums)}
          hint="Aktiv və təsdiqlənmiş"
          icon={<MapPin />}
          loading={stats.isLoading}
        />
        <StatCard
          label="Owner sorğuları"
          value={statValue(stats.data?.pendingOwnerRequests)}
          hint="Moderasiya növbəsi"
          icon={<UserCheck />}
          loading={stats.isLoading}
        />
      </div>

      {bookings.isLoading ? (
        <Skeleton className="h-[19rem] w-full rounded-lg" />
      ) : bookings.isError ? (
        <ErrorState
          title="Rezervasiya məlumatı yüklənmədi"
          description={errorMessage(bookings.error)}
          onRetry={() => void bookings.refetch()}
        />
      ) : (
        <ChartCard
          title="Rezervasiyalar (aylıq)"
          description={`Son ${SAMPLE_SIZE} rezervasiya əsasında hesablanıb — platforma üzrə zaman seriyası endpoint-i yoxdur.`}
          isEmpty={points.length === 0}
          emptyLabel="Son rezervasiyalarda tarixi oxunan bron yoxdur"
          height={280}
        >
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={points} margin={{ top: 8, right: 12, bottom: 0, left: 0 }}>
              <CartesianGrid vertical={false} stroke={chartTheme.grid} />
              <XAxis dataKey="label" {...axisProps} />
              <YAxis {...axisProps} width={44} allowDecimals={false} />
              <RechartsTooltip
                cursor={{ fill: chartTheme.seriesSoft }}
                content={
                  <ChartTooltip formatter={(value) => `${formatNumber(value)} rezervasiya`} />
                }
              />
              <Bar
                dataKey="value"
                fill={chartTheme.series}
                radius={[4, 4, 0, 0]}
                maxBarSize={38}
              />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>
      )}

      <Card>
        <CardHeader
          title="Status paylanması"
          description={`Son ${SAMPLE_SIZE} rezervasiyanın interfeys statusları.`}
        />
        <CardBody>
          {items.length === 0 ? (
            <p className="text-[13px] text-ink-500">Hesablamaq üçün rezervasiya yoxdur.</p>
          ) : (
            <ul className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
              {STATES.map((state) => (
                <li
                  key={state}
                  className="flex items-center justify-between gap-3 rounded-md border border-line bg-ink-50/50 px-3.5 py-3"
                >
                  <BookingStatusBadge status={state} />
                  <span className="text-lg font-bold tabular-nums text-ink-900">
                    {formatNumber(byState.get(state) ?? 0)}
                  </span>
                </li>
              ))}
            </ul>
          )}
        </CardBody>
      </Card>

      <MissingEndpointNotice
        title="Platforma analitikası endpoint-i yoxdur"
        description="Backend gəlir, doluluq və istifadəçi artımı üzrə hazır zaman seriyası qaytarmır. Yuxarıdakı qrafik yalnız son rezervasiyalar səhifəsindən hesablanır, ona görə uzun dövr üzrə trend kimi oxunmamalıdır. Endpoint açılan kimi bu bölmə real analitikaya keçəcək."
        endpoint="GET /api/Analytics/platform"
      />
    </div>
  )
}
