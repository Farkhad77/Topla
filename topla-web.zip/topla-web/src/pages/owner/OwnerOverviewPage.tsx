import { useMemo } from 'react'
import { Link } from 'react-router-dom'
import { CalendarDays, Clock, Gauge, MapPin, Plus, Star, Wallet } from 'lucide-react'
import {
  Button,
  EmptyState,
  ErrorState,
  InlineNote,
  Skeleton,
  StatCard,
} from '@/components/ui'
import { OwnerPageHeader } from '@/features/owner/OwnerPageHeader'
import { CountBarChart, RevenueAreaChart } from '@/features/owner/OwnerCharts'
import { PendingBookingsPanel } from '@/features/owner/PendingBookingsPanel'
import { OWNER_BOOKINGS_SAMPLE, useOwnerStadiums } from '@/features/owner/useOwnerStadiums'
import { useOwnerReviews } from '@/features/owner/useOwnerReviews'
import { useOwnerBookings } from '@/hooks/queries/useBookingQueries'
import { usePageMeta } from '@/hooks/usePageMeta'
import { buildOwnerAnalytics } from '@/services'
import { errorMessage } from '@/api'
import { BookingStatus } from '@/types'
import { formatNumber, formatPercent, formatPrice, toDate } from '@/utils/format'

export default function OwnerOverviewPage() {
  usePageMeta({ title: 'Ümumi baxış — Biznes paneli' })

  const stadiums = useOwnerStadiums()
  const bookingsQuery = useOwnerBookings(OWNER_BOOKINGS_SAMPLE)
  const stadiumIds = useMemo(() => stadiums.options.map((option) => option.value), [stadiums.options])
  const reviews = useOwnerReviews(stadiumIds)

  const bookings = useMemo(() => bookingsQuery.data?.items ?? [], [bookingsQuery.data])

  const analytics = useMemo(
    () =>
      buildOwnerAnalytics({
        bookings,
        stadiums: stadiums.entries.map((entry) => entry.stadium),
        averageRating: reviews.averageRating,
        totalReviews: reviews.totalReviews,
      }),
    [bookings, stadiums.entries, reviews.averageRating, reviews.totalReviews],
  )

  const pending = useMemo(
    () =>
      bookings
        .filter((booking) => booking.status === BookingStatus.Pending)
        .sort(
          (a, b) =>
            (toDate(a.startDateTime)?.getTime() ?? 0) - (toDate(b.startDateTime)?.getTime() ?? 0),
        ),
    [bookings],
  )

  const isLoading = bookingsQuery.isLoading || stadiums.isLoading

  if (bookingsQuery.isError) {
    return (
      <div className="space-y-5">
        <OwnerPageHeader title="Ümumi baxış" />
        <ErrorState
          title="Panel məlumatı yüklənmədi"
          description={errorMessage(bookingsQuery.error)}
          onRetry={() => void bookingsQuery.refetch()}
        />
      </div>
    )
  }

  if (!isLoading && stadiums.entries.length === 0) {
    return (
      <div className="space-y-5">
        <OwnerPageHeader
          title="Ümumi baxış"
          description="Panel real rezervasiya datası üzərində işləyir — ilk stadionu əlavə edən kimi rəqəmlər burada canlanacaq."
        />
        <EmptyState
          icon={<MapPin />}
          title="Hələ stadionun yoxdur"
          description="İlk meydançanı əlavə et: ad, ünvan, qiymət və iş saatları — 2 dəqiqəlik iş."
          action={
            <Button asChild>
              <Link to="/owner/stadiums/new">Stadion əlavə et</Link>
            </Button>
          }
        />
      </div>
    )
  }

  const kpis = analytics.kpis

  return (
    <div className="space-y-5">
      <OwnerPageHeader
        title="Ümumi baxış"
        description="Bütün göstəricilər son 100 rezervasiyadan hesablanır — backend-də hazır analitika endpoint-i yoxdur."
        action={
          <Button asChild>
            <Link to="/owner/stadiums/new">
              <Plus />
              Stadion əlavə et
            </Link>
          </Button>
        }
      />

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-5">
        <StatCard
          label="Bugünkü bronlar"
          value={formatNumber(kpis.todayBookings)}
          hint="Bu gün başlayan rezervasiyalar"
          icon={<CalendarDays />}
          loading={isLoading}
        />
        <StatCard
          label="Gözləyən bronlar"
          value={formatNumber(kpis.pendingBookings)}
          hint="Cavabını gözləyir"
          icon={<Clock />}
          tone={kpis.pendingBookings > 0 ? 'warning' : 'default'}
          loading={isLoading}
        />
        <StatCard
          label="Bu ayın gəliri"
          value={formatPrice(kpis.revenueThisMonth)}
          hint="Ləğv edilənlər sayılmır"
          icon={<Wallet />}
          tone="brand"
          loading={isLoading}
        />
        <StatCard
          label="Doluluk"
          value={formatPercent(kpis.occupancyRate)}
          hint="Bu ayın iş saatlarına nisbətən"
          icon={<Gauge />}
          loading={isLoading}
        />
        <StatCard
          label="Orta reytinq"
          value={kpis.totalReviews ? kpis.averageRating.toFixed(1) : '—'}
          hint={kpis.totalReviews ? `${formatNumber(kpis.totalReviews)} rəy` : 'Hələ rəy yoxdur'}
          icon={<Star />}
          loading={isLoading || reviews.isLoading}
        />
      </div>

      {isLoading ? (
        <div className="grid gap-4 lg:grid-cols-2">
          {Array.from({ length: 4 }).map((_, index) => (
            <Skeleton key={index} className="h-[17rem] w-full rounded-lg" />
          ))}
        </div>
      ) : (
        <>
          <PendingBookingsPanel bookings={pending} />

          <div className="grid gap-4 lg:grid-cols-2">
            <RevenueAreaChart
              title="Gəlir (aylıq)"
              description="Son 6 ay, manatla"
              data={analytics.revenueByMonth}
              emptyLabel="Bu dövrdə gəlir qeydə alınmayıb"
              formatter={(value) => formatPrice(value)}
            />
            <CountBarChart
              title="Rezervasiyalar (aylıq)"
              description="Son 6 ayda bronların sayı"
              data={analytics.bookingsByMonth}
              emptyLabel="Bu dövrdə rezervasiya yoxdur"
              formatter={(value) => `${formatNumber(value)} bron`}
            />
            <CountBarChart
              title="Həftənin günləri üzrə bronlar"
              description="Hansı günlər daha çox dolur"
              data={analytics.bookingsByWeekday}
              emptyLabel="Gün üzrə paylanma üçün data yoxdur"
              formatter={(value) => `${formatNumber(value)} bron`}
            />
            <CountBarChart
              title="Pik saatlar"
              description="Bronların başlama saatı üzrə paylanması"
              data={analytics.peakHours}
              emptyLabel="Saat üzrə paylanma üçün data yoxdur"
              formatter={(value) => `${formatNumber(value)} bron`}
            />
          </div>
        </>
      )}

      <InlineNote tone="info">
        Doluluk göstəricisi stadionların iş saatları və bu ayın keçmiş günləri əsasında hesablanır.
        Backend analitika endpoint-i açılanda bu hesablama real API dəyərləri ilə əvəzlənəcək.
      </InlineNote>
    </div>
  )
}
