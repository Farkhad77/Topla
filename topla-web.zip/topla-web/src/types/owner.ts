/** Backend enum: 0 Pending, 1 Approved, 2 Rejected */
export const ApprovalStatus = {
  Pending: 0,
  Approved: 1,
  Rejected: 2,
} as const
export type ApprovalStatusValue = (typeof ApprovalStatus)[keyof typeof ApprovalStatus]

export interface OwnerRequest {
  id: string
  userId: string
  fullName: string
  email: string
  message: string | null
  status: ApprovalStatusValue
  createdAt: string
  rejectReason: string | null
}

export interface BlockedSlot {
  id: string
  stadiumId: string
  startTime: string
  endTime: string
  reason: string | null
}

export interface BlockedSlotCreatePayload {
  startTime: string
  endTime: string
  reason?: string
}

export interface Worker {
  userId: string
  fullName: string
  email: string
  isActive: boolean
  createdAt: string
}

export interface WorkerBusiness {
  ownerProfileId: string
  stadiums: { id: string; name: string; city: string }[]
}

/** Owner analitikası — backend-də endpoint yoxdur, bookings-dən hesablanır. */
export interface OwnerKpis {
  totalBookings: number
  todayBookings: number
  upcomingBookings: number
  pendingBookings: number
  revenueTotal: number
  revenueThisMonth: number
  occupancyRate: number
  averageRating: number
  totalReviews: number
}

export interface TimeSeriesPoint {
  label: string
  value: number
}

export interface OwnerAnalytics {
  kpis: OwnerKpis
  revenueByMonth: TimeSeriesPoint[]
  bookingsByMonth: TimeSeriesPoint[]
  bookingsByWeekday: TimeSeriesPoint[]
  peakHours: TimeSeriesPoint[]
  revenueByStadium: TimeSeriesPoint[]
}
