import { format, formatDistanceToNowStrict, isValid, parseISO } from 'date-fns'
import { az } from 'date-fns/locale'
import { CURRENCY } from './constants'

/**
 * Backend DateTime-ları saat qurşağı sonluğu olmadan gəlir ("2026-08-17T18:00:00"),
 * yəni "divar saatı" dəyəridir. Onları UTC-yə çevirmirik — olduğu kimi göstəririk.
 */
export function toDate(value: string | Date | null | undefined): Date | null {
  if (!value) return null
  if (value instanceof Date) return isValid(value) ? value : null
  const parsed = parseISO(value)
  return isValid(parsed) ? parsed : null
}

/** Backend-ə göndərmək üçün: saat qurşağı sonluğu OLMADAN yerli divar saatı. */
export function toWallClockIso(date: Date): string {
  return format(date, "yyyy-MM-dd'T'HH:mm:ss")
}

export function toDateParam(date: Date): string {
  return format(date, 'yyyy-MM-dd')
}

export function formatDate(value: string | Date | null | undefined): string {
  const date = toDate(value)
  return date ? format(date, 'd MMMM yyyy', { locale: az }) : '—'
}

export function formatShortDate(value: string | Date | null | undefined): string {
  const date = toDate(value)
  return date ? format(date, 'd MMM', { locale: az }) : '—'
}

export function formatWeekday(value: string | Date | null | undefined): string {
  const date = toDate(value)
  return date ? format(date, 'EEEE', { locale: az }) : '—'
}

export function formatTime(value: string | Date | null | undefined): string {
  const date = toDate(value)
  return date ? format(date, 'HH:mm') : '—'
}

export function formatDateTime(value: string | Date | null | undefined): string {
  const date = toDate(value)
  return date ? format(date, 'd MMM yyyy, HH:mm', { locale: az }) : '—'
}

export function formatTimeRange(
  start: string | Date | null | undefined,
  end: string | Date | null | undefined,
): string {
  const from = formatTime(start)
  const to = formatTime(end)
  if (from === '—' || to === '—') return '—'
  return `${from}–${to}`
}

export function formatRelative(value: string | Date | null | undefined): string {
  const date = toDate(value)
  if (!date) return '—'
  return `${formatDistanceToNowStrict(date, { locale: az })} əvvəl`
}

export function formatPrice(value: number | null | undefined, withUnit = false): string {
  if (value == null || Number.isNaN(value)) return '—'
  const rounded = Math.round(value * 100) / 100
  const text = new Intl.NumberFormat('az-AZ', {
    minimumFractionDigits: Number.isInteger(rounded) ? 0 : 2,
    maximumFractionDigits: 2,
  }).format(rounded)
  return `${text} ${CURRENCY}${withUnit ? '/saat' : ''}`
}

export function formatNumber(value: number | null | undefined): string {
  if (value == null || Number.isNaN(value)) return '—'
  return new Intl.NumberFormat('az-AZ').format(value)
}

export function formatPercent(value: number | null | undefined): string {
  if (value == null || Number.isNaN(value)) return '—'
  return `${Math.round(value)}%`
}

/** "18:00:00" → "18:00" */
export function formatTimeOnly(value: string | null | undefined): string {
  if (!value) return '—'
  const [h = '00', m = '00'] = value.split(':')
  return `${h.padStart(2, '0')}:${m}`
}

export function initials(name: string | null | undefined): string {
  if (!name) return '?'
  return name
    .trim()
    .split(/\s+/)
    .slice(0, 2)
    .map((part) => part[0]?.toUpperCase() ?? '')
    .join('')
}

export function formatDuration(minutes: number): string {
  if (minutes < 60) return `${minutes} dəq`
  const hours = Math.floor(minutes / 60)
  const rest = minutes % 60
  return rest === 0 ? `${hours} saat` : `${hours} saat ${rest} dəq`
}
