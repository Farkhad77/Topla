import { format, getDay, getHours, isSameMonth, isToday, parseISO } from 'date-fns'
import { az } from 'date-fns/locale'
import { BookingStatus } from '@/types'
import type { OwnerAnalytics, OwnerBooking, OwnerStadium, TimeSeriesPoint } from '@/types'
import { timeOnlyToMinutes } from '@/utils/booking'

/**
 * Backend-də owner analitika endpoint-i YOXDUR.
 * Ona görə göstəricilər real rezervasiya datasından client-side hesablanır —
 * heç bir uydurma rəqəm yoxdur. Backend analitika endpoint-i əlavə edəndə
 * yalnız bu fayl real API çağırışı ilə əvəzlənməlidir.
 */

const WEEKDAY_ORDER = [1, 2, 3, 4, 5, 6, 0]

function revenueOf(booking: OwnerBooking): number {
  return booking.status === BookingStatus.Cancelled ? 0 : booking.totalPrice
}

function monthKey(date: Date): string {
  return format(date, 'yyyy-MM')
}

export function buildOwnerAnalytics(input: {
  bookings: OwnerBooking[]
  stadiums: OwnerStadium[]
  averageRating?: number
  totalReviews?: number
  monthsBack?: number
}): OwnerAnalytics {
  const { bookings, stadiums, averageRating = 0, totalReviews = 0, monthsBack = 6 } = input
  const now = new Date()

  const parsed = bookings
    .map((booking) => ({ booking, start: parseISO(booking.startDateTime) }))
    .filter((entry) => !Number.isNaN(entry.start.getTime()))

  const revenueTotal = bookings.reduce((sum, booking) => sum + revenueOf(booking), 0)
  const revenueThisMonth = parsed
    .filter((entry) => isSameMonth(entry.start, now))
    .reduce((sum, entry) => sum + revenueOf(entry.booking), 0)

  const months: TimeSeriesPoint[] = []
  const bookingsPerMonth: TimeSeriesPoint[] = []
  const revenueByMonthMap = new Map<string, number>()
  const countByMonthMap = new Map<string, number>()

  parsed.forEach((entry) => {
    const key = monthKey(entry.start)
    revenueByMonthMap.set(key, (revenueByMonthMap.get(key) ?? 0) + revenueOf(entry.booking))
    countByMonthMap.set(key, (countByMonthMap.get(key) ?? 0) + 1)
  })

  for (let offset = monthsBack - 1; offset >= 0; offset -= 1) {
    const date = new Date(now.getFullYear(), now.getMonth() - offset, 1)
    const key = monthKey(date)
    const label = format(date, 'LLL', { locale: az })
    months.push({ label, value: Math.round(revenueByMonthMap.get(key) ?? 0) })
    bookingsPerMonth.push({ label, value: countByMonthMap.get(key) ?? 0 })
  }

  const weekdayCounts = new Map<number, number>()
  const hourCounts = new Map<number, number>()
  const stadiumRevenue = new Map<string, number>()

  parsed.forEach((entry) => {
    const day = getDay(entry.start)
    weekdayCounts.set(day, (weekdayCounts.get(day) ?? 0) + 1)
    const hour = getHours(entry.start)
    hourCounts.set(hour, (hourCounts.get(hour) ?? 0) + 1)
    stadiumRevenue.set(
      entry.booking.stadiumName,
      (stadiumRevenue.get(entry.booking.stadiumName) ?? 0) + revenueOf(entry.booking),
    )
  })

  const bookingsByWeekday: TimeSeriesPoint[] = WEEKDAY_ORDER.map((day) => ({
    label: format(new Date(2024, 0, 1 + ((day + 6) % 7)), 'EEEEEE', { locale: az }),
    value: weekdayCounts.get(day) ?? 0,
  }))

  const peakHours: TimeSeriesPoint[] = Array.from(hourCounts.entries())
    .sort((a, b) => a[0] - b[0])
    .map(([hour, value]) => ({ label: `${String(hour).padStart(2, '0')}:00`, value }))

  const revenueByStadium: TimeSeriesPoint[] = Array.from(stadiumRevenue.entries())
    .map(([label, value]) => ({ label, value: Math.round(value) }))
    .sort((a, b) => b.value - a.value)
    .slice(0, 6)

  // Doluluk: bu ayın rezervasiya saatları / stadionların ümumi iş saatı tutumu
  const daysSoFar = now.getDate()
  const capacityHours = stadiums.reduce((sum, stadium) => {
    const open = timeOnlyToMinutes(stadium.openTime ?? '00:00:00')
    const close = timeOnlyToMinutes(stadium.closeTime ?? '00:00:00')
    const perDay = Math.max(0, close - open) / 60
    return sum + perDay * daysSoFar
  }, 0)

  const bookedHours = parsed
    .filter((entry) => isSameMonth(entry.start, now) && entry.booking.status !== BookingStatus.Cancelled)
    .reduce((sum, entry) => {
      const end = parseISO(entry.booking.endDateTime)
      if (Number.isNaN(end.getTime())) return sum
      return sum + (end.getTime() - entry.start.getTime()) / 3_600_000
    }, 0)

  return {
    kpis: {
      totalBookings: bookings.length,
      todayBookings: parsed.filter((entry) => isToday(entry.start)).length,
      upcomingBookings: parsed.filter((entry) => entry.start.getTime() > now.getTime()).length,
      pendingBookings: bookings.filter((booking) => booking.status === BookingStatus.Pending).length,
      revenueTotal,
      revenueThisMonth,
      occupancyRate: capacityHours > 0 ? Math.min(100, (bookedHours / capacityHours) * 100) : 0,
      averageRating,
      totalReviews,
    },
    revenueByMonth: months,
    bookingsByMonth: bookingsPerMonth,
    bookingsByWeekday,
    peakHours,
    revenueByStadium,
  }
}
