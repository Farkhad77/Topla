import { bookingService } from './bookingService'
import { moderationService } from './moderationService'
import { stadiumService } from './stadiumService'
import { FEATURES } from '@/utils/constants'
import type { PagedResult, StadiumListItem, UserSummary } from '@/types'
import { emptyPage } from '@/types'

/**
 * ADMIN QATI — API BOŞLUQLARI
 * ----------------------------------------------------------------------
 * Backend-də `IUserService.GetAllAsync` və pending stadion siyahısı MÖVCUDDUR,
 * amma heç bir controller onları açmır. Ona görə burada tipli interfeys saxlanılır
 * və endpoint gələnə qədər boş nəticə qaytarılır (uydurma data DEYİL).
 *
 * Endpoint əlavə olunanda: FEATURES.adminUserList = true et və aşağıdakı
 * `http.get(...)` sətrini şərhdən çıxar — komponentlərdə heç nə dəyişmir.
 */
export interface AdminUserQuery {
  pageNumber: number
  pageSize: number
  search?: string
}

export const adminService = {
  async users(query: AdminUserQuery): Promise<PagedResult<UserSummary>> {
    if (!FEATURES.adminUserList) return emptyPage<UserSummary>(query.pageSize)
    // TODO(backend): `GET /api/Users?pageNumber=&pageSize=` açılanda:
    // const data = await http.get<unknown>('/api/Users', { params: query })
    // return unwrapPage<UserSummary>(data, query.pageSize)
    return emptyPage<UserSummary>(query.pageSize)
  },

  async pendingStadiums(): Promise<StadiumListItem[]> {
    if (!FEATURES.adminStadiumQueue) return []
    // TODO(backend): `GET /api/Moderators/stadiums?status=Pending` açılmalıdır.
    return []
  },

  /** Platforma statistikası — mövcud olan real endpoint-lərdən yığılır. */
  async platformStats() {
    const [requests, bookings, stadiums] = await Promise.all([
      moderationService.ownerRequests(1, 1).catch(() => emptyPage(1)),
      bookingService.all(1, 1).catch(() => emptyPage(1)),
      stadiumService.list(1, 1).catch(() => emptyPage(1)),
    ])

    return {
      pendingOwnerRequests: requests.totalCount,
      totalBookings: bookings.totalCount,
      publishedStadiums: stadiums.totalCount,
    }
  },
}
