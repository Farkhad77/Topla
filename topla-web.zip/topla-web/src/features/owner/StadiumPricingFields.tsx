import type { UseFormReturn } from 'react-hook-form'
import { Card, CardBody, CardHeader, Field, FormRow, Input } from '@/components/ui'
import type { StadiumFormValues } from '@/schemas/stadium'

export function StadiumPricingFields({ form }: { form: UseFormReturn<StadiumFormValues> }) {
  const {
    register,
    formState: { errors },
  } = form

  return (
    <>
      <Card>
        <CardHeader
          title="Qiymət və müddət"
          description="Axşam saatlarına (18:00–22:00) sistem avtomatik 1.5x tarif tətbiq edir."
        />
        <CardBody className="space-y-4">
          <Field label="Saatlıq qiymət (₼)" required error={errors.pricePerHour?.message}>
            {({ id, describedBy, invalid }) => (
              <Input
                id={id}
                type="number"
                step="1"
                min={1}
                inputMode="decimal"
                aria-describedby={describedBy}
                invalid={invalid}
                placeholder="60"
                {...register('pricePerHour')}
              />
            )}
          </Field>

          <FormRow>
            <Field label="Minimum bron (dəqiqə)" required error={errors.minBookingMinutes?.message}>
              {({ id, describedBy, invalid }) => (
                <Input
                  id={id}
                  type="number"
                  step="30"
                  min={30}
                  aria-describedby={describedBy}
                  invalid={invalid}
                  {...register('minBookingMinutes')}
                />
              )}
            </Field>

            <Field label="Maksimum bron (dəqiqə)" required error={errors.maxBookingMinutes?.message}>
              {({ id, describedBy, invalid }) => (
                <Input
                  id={id}
                  type="number"
                  step="30"
                  min={30}
                  aria-describedby={describedBy}
                  invalid={invalid}
                  {...register('maxBookingMinutes')}
                />
              )}
            </Field>
          </FormRow>
        </CardBody>
      </Card>

      <Card>
        <CardHeader
          title="İş saatları"
          description="Bu aralıqdan kənarda heç kim bron edə bilməyəcək."
        />
        <CardBody>
          <FormRow>
            <Field label="Açılış" required error={errors.openTime?.message}>
              {({ id, describedBy, invalid }) => (
                <Input
                  id={id}
                  type="time"
                  aria-describedby={describedBy}
                  invalid={invalid}
                  {...register('openTime')}
                />
              )}
            </Field>

            <Field label="Bağlanış" required error={errors.closeTime?.message}>
              {({ id, describedBy, invalid }) => (
                <Input
                  id={id}
                  type="time"
                  aria-describedby={describedBy}
                  invalid={invalid}
                  {...register('closeTime')}
                />
              )}
            </Field>
          </FormRow>
        </CardBody>
      </Card>
    </>
  )
}
