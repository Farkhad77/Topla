import { useState } from 'react'
import { Link } from 'react-router-dom'
import { ArrowRight, BellRing, Check, CheckCircle2, X } from 'lucide-react'
import { Button, Card, CardBody, CardFooter, CardHeader, EmptyState } from '@/components/ui'
import { RejectBookingDialog } from './RejectBookingDialog'
import { useConfirmBooking, useRejectBooking } from '@/hooks/queries/useBookingQueries'
import { formatDate, formatPrice, formatTimeRange } from '@/utils/format'
import type { OwnerBooking } from '@/types'

const VISIBLE_LIMIT = 5

/** Sahibkarın ilk baxışda görməli olduğu tək şey: cavab gözləyən bronlar. */
export function PendingBookingsPanel({ bookings }: { bookings: OwnerBooking[] }) {
  const confirmBooking = useConfirmBooking()
  const rejectBooking = useRejectBooking()
  const [rejectTarget, setRejectTarget] = useState<OwnerBooking | null>(null)
  const [busyId, setBusyId] = useState<string | null>(null)

  const visible = bookings.slice(0, VISIBLE_LIMIT)

  async function handleConfirm(booking: OwnerBooking) {
    setBusyId(booking.bookingId)
    try {
      await confirmBooking.mutateAsync(booking.bookingId)
    } catch {
      // Xəta mesajı mutation hook-unda toast kimi göstərilir.
    } finally {
      setBusyId(null)
    }
  }

  async function handleReject(booking: OwnerBooking, reason: string) {
    try {
      await rejectBooking.mutateAsync({ bookingId: booking.bookingId, reason })
      setRejectTarget(null)
    } catch {
      // Dialoq açıq qalır ki, istifadəçi yenidən cəhd edə bilsin.
    }
  }

  return (
    <Card>
      <CardHeader
        title="Diqqət tələb edir"
        description="Təsdiq gözləyən rezervasiyalar — cavab verməsən müştəri gözləməkdə qalır."
        action={
          bookings.length ? (
            <span className="rounded-full bg-warning-soft px-2.5 py-1 text-xs font-bold text-warning">
              {bookings.length} gözləyir
            </span>
          ) : null
        }
      />

      <CardBody>
        {visible.length === 0 ? (
          <EmptyState
            icon={<CheckCircle2 />}
            title="Gözləyən bron yoxdur"
            description="Bütün sorğulara cavab verilib. Yeni bron gələndə burada görünəcək."
            compact
          />
        ) : (
          <ul className="space-y-3">
            {visible.map((booking) => (
              <li
                key={booking.bookingId}
                className="flex flex-col gap-3 rounded-md border border-warning/25 bg-warning-soft/40 p-3.5 sm:flex-row sm:items-center sm:justify-between"
              >
                <div className="min-w-0">
                  <p className="truncate text-[13.5px] font-bold text-ink-900">
                    {booking.customerName || 'Ad göstərilməyib'}
                    <span className="ml-2 font-medium text-ink-500">{booking.stadiumName}</span>
                  </p>
                  <p className="mt-0.5 text-xs text-ink-600">
                    {formatDate(booking.startDateTime)} ·{' '}
                    {formatTimeRange(booking.startDateTime, booking.endDateTime)} ·{' '}
                    {formatPrice(booking.totalPrice)}
                  </p>
                </div>

                <div className="flex shrink-0 items-center gap-2">
                  <Button
                    size="sm"
                    className="min-h-10 flex-1 sm:flex-none"
                    loading={busyId === booking.bookingId}
                    onClick={() => void handleConfirm(booking)}
                  >
                    <Check />
                    Təsdiq
                  </Button>
                  <Button
                    size="sm"
                    variant="secondary"
                    className="min-h-10 flex-1 sm:flex-none"
                    disabled={busyId === booking.bookingId}
                    onClick={() => setRejectTarget(booking)}
                  >
                    <X />
                    Rədd
                  </Button>
                </div>
              </li>
            ))}
          </ul>
        )}
      </CardBody>

      {bookings.length > VISIBLE_LIMIT ? (
        <CardFooter>
          <Button variant="link" asChild>
            <Link to="/owner/bookings">
              <BellRing />
              Qalan {bookings.length - VISIBLE_LIMIT} sorğunu gör
              <ArrowRight />
            </Link>
          </Button>
        </CardFooter>
      ) : null}

      <RejectBookingDialog
        booking={rejectTarget}
        loading={rejectBooking.isPending}
        onOpenChange={(open) => {
          if (!open) setRejectTarget(null)
        }}
        onSubmit={(booking, reason) => void handleReject(booking, reason)}
      />
    </Card>
  )
}
