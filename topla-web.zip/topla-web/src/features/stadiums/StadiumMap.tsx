import { ExternalLink, MapPin } from 'lucide-react'

/**
 * Xəritə: API açarı tələb etməyən OpenStreetMap embed.
 * Koordinat 0,0 olarsa (backend-də doldurulmayıbsa) xəritə göstərilmir.
 */
export function StadiumMap({
  latitude,
  longitude,
  address,
  name,
}: {
  latitude: number
  longitude: number
  address: string
  name: string
}) {
  const hasCoordinates = Number.isFinite(latitude) && Number.isFinite(longitude) && (latitude !== 0 || longitude !== 0)

  if (!hasCoordinates) {
    return (
      <div className="flex items-start gap-2.5 rounded-md border border-line bg-ink-50 px-4 py-3.5 text-[13px] text-ink-600">
        <MapPin className="mt-0.5 size-4 shrink-0 text-ink-400" aria-hidden="true" />
        <span>{address || 'Ünvan göstərilməyib'}</span>
      </div>
    )
  }

  const delta = 0.004
  const bbox = [longitude - delta, latitude - delta / 2, longitude + delta, latitude + delta / 2].join(',')

  return (
    <div className="overflow-hidden rounded-md border border-line">
      <iframe
        title={`${name} xəritədə`}
        src={`https://www.openstreetmap.org/export/embed.html?bbox=${bbox}&layer=mapnik&marker=${latitude},${longitude}`}
        className="h-56 w-full border-0"
        loading="lazy"
        referrerPolicy="no-referrer-when-downgrade"
      />
      <div className="flex items-center justify-between gap-3 border-t border-line bg-surface px-4 py-3">
        <p className="flex items-start gap-2 text-[13px] text-ink-700">
          <MapPin className="mt-0.5 size-4 shrink-0 text-brand-700" aria-hidden="true" />
          {address}
        </p>
        <a
          href={`https://www.openstreetmap.org/?mlat=${latitude}&mlon=${longitude}#map=17/${latitude}/${longitude}`}
          target="_blank"
          rel="noreferrer noopener"
          className="inline-flex shrink-0 items-center gap-1 text-xs font-semibold text-brand-700 hover:underline"
        >
          Xəritədə aç
          <ExternalLink className="size-3.5" />
        </a>
      </div>
    </div>
  )
}
